var fs = require('fs');
var express = require('express');
var app = express();
var moment = require('moment');
var _ = require('underscore');

var authtoken = '19bfeb851f905f40838bb3006162f9996632cb06386e606a0c1d831e35ef062d'; // Auth token
var pmusid = 'todo_set_a_proper_pmu_session_id'; // PMU Session Id
var fetchTimestamp = 1372422148000; // Timestamp correspondant à la date de récupération de programme-actif.json
var jsonResType = 'application/json; charset=utf-8';

app.use(express.static(__dirname + '/public'));
app.use(express.bodyParser());
app.use(express.cookieParser());

/*
 *  Convenient methods
 */
function readFileAndReturnData(fileName, res, resCode) {
    fs.readFile(fileName, 'utf8', function (err, data) {
        res.type(jsonResType);

        if (err) {
            res.send(500);
        }

	if (resCode == 401) {
	    res.setHeader('WWW-Authenticate', 'OAuth realm="users"');
	}

        res.send(resCode, data);
    });
}

/*
 * GET
 * Rapports definitifs
 */
app.get('/:file', function (req, res) {
    res.type(jsonResType);
    readFileAndReturnData('data/' + req.params.file, res, 200);
});

/*
 * GET
 * Tirelire
 */
app.get('/turfInfo/client/:clientid/tirelire', function (req, res) {
    res.type(jsonResType);
    readFileAndReturnData('data/tirelire.json', res, 200);
});

app.get('/turfInfo/client/:clientid/tirelire/:date', function (req, res) {
    res.type(jsonResType);
    readFileAndReturnData('data/tirelire.json', res, 200);
});

/*
 * GET
 * Most played combinations
 */
app.get('/turfInfo/client/:clientid/programme/:date/:meeting/:race/combinaisons', function (req, res) {
    res.type(jsonResType);
    readFileAndReturnData('data/most_played_combinations.json', res, 200);
});

/*
 * GET
 * Most forecasts
 */
app.get('/turfInfo/client/:clientid/pronostics/:date/:meeting/:race', function (req, res) {
    res.type(jsonResType);
    if (req.query.commentaire == "true") {
        readFileAndReturnData('data/forecasts.json', res, 200);    
    }    
});

/*
 * GET
 * Offre de bienvenue
 */
app.get('/natifs/turf/ws/turf/reglages/:deviceName', function (req, res) {
    res.type(jsonResType);
    if (req.params.deviceName == 'android-smartphone') {
        readFileAndReturnData('data/drupal-reglages-android.json', res, 200);
    } else {
        readFileAndReturnData('data/drupal-reglages.json', res, 200);
    }
});

app.get('/natifs/turf/ws/turf/reglages/:deviceName/:jsonFile', function (req, res) {
    res.redirect('natifs/turf/ws/turf/reglages/' + req.params.deviceName);        
});

app.get('/ws/turf/reglages/:deviceName', function (req, res) {
    res.redirect('natifs/turf/ws/turf/reglages/' + req.params.deviceName);
});

/*
 * GET
 * Mises en avant 
 */
app.get('/natifs/turf/ws/turf/mises_en_avant/:deviceName', function (req, res) {
    res.type(jsonResType);
    readFileAndReturnData('data/drupal-misesenavant.json', res, 200);        
});

app.get('/natifs/turf/ws/turf/mises_en_avant/:deviceName/:jsonFile', function (req, res) {
    res.redirect('natifs/turf/ws/turf/mises_en_avant/' + req.params.deviceName);        
});

app.get('/ws/turf/mises_en_avant/:deviceName', function (req, res) {
    res.redirect('natifs/turf/ws/turf/mises_en_avant/' + req.params.deviceName);        
});

/*
 * POST
 * Push Notifications
 */
app.post('/webservices/alert/register/:appId/:platform/:deviceToken/:append', function (req, res) {
    res.type(jsonResType);
    readFileAndReturnData('data/pn-subscription-response.json', res, 200);        
});

/*
 * GET
 * Probable reports
 */
 app.get('/turfInfo/client/:clientid/:programmes/:date/:meeting/:race/rapports/:betType', function (req, res) {
    res.type(jsonResType);

    if (req.params.betType == 'SIMPLE_PLACE') {
        readFileAndReturnData('data/pr_simple_place.json', res, 200);        
    } else if (req.params.betType == 'COUPLE_GAGNANT') {
        readFileAndReturnData('data/pr_couple_gagnant.json', res, 200);        
    } else if (req.params.betType == 'COUPLE_ORDRE') {
        readFileAndReturnData('data/pr_couple_ordre.json', res, 200);        
    } else {
        readFileAndReturnData('data/unauthorized.json', res, 401);
    }
});

/*
 *  GET
 *  Pronostics-detailles
 */
app.get('/turfInfo/client/:clientid/:programmes/:date/:meeting/:race/pronostics-detailles', function (req, res) {
    res.type(jsonResType);

    if ((req.params.meeting == 'R1' && req.params.race == 'C3') ||
        (req.params.meeting == 'R3' && req.params.race == 'C3')) {
        readFileAndReturnData('data/pronostics-detailles-quinte.json', res, 200);        
    } else {
        readFileAndReturnData('data/pronostics-detailles.json', res, 200);        
    }
}); 

/*
 * POST
 * Redirect all the post requests on PMU PP
 */
app.post('^*$', function (req, res) {
    res.redirect('http://liv1-front.pmu.aw.atos.net' + req.path);
});

/*
 * GET
 * Redirect all the get requests on PMU PP
 */
app.get('^*$', function (req, res) {
    res.redirect('http://liv1-front.pmu.aw.atos.net' + req.path);
});

app.listen(8082);
