#!/bin/bash


if [ "$#" -ne 2 ]
then
  echo "Usage: ./refresh.sh <git cloned repo> <target folder>"
  exit 1
fi

if [ ! -d "$1" ];
then
	echo "$1 folder does not exist"
	exit 1
fi

if [ ! -d "$2" ];
then
	echo "$2 folder does not exist"
	exit 1
fi

cd $1
if ! git rev-parse --is-inside-work-tree;
then
	echo "$1 folder is not under git control"
	exit 1
fi

# updating the git repo
git pull

# Copy the updated repo to the folder where the node.js server is begin
# executed
cp -R $1/www-mockup/ $2/.

# Moving to the second folder
cd $2

# Restarting the server
forever stop pmu-hippique.js
forever start pmu-hippique.js

# All done
echo "DONE !"